# Python Fundamentos

******* Todos os scripts foram atualizados para a versão 3.6.1 da Linguagem Python em 05/06/2017 *******

Data Science Academy - Python Fundamentos para Análise de Dados

Seja Bem-vindo ao Repositório do curso Python Fundamentos para Análise de Dados. Aqui você encontra todos os Jupyter Notebooks usados no curso, bem como os exercícios. 


https://www.datascienceacademy.com.br



